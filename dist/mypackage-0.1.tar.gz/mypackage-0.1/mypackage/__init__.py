from . import myModule  
